# Ukraine online source for Lampac

- [x] AnimeON
- [ ] AnimeUA
- [ ] Anitubeinua
- [ ] BambooUA
- [x] CikavaIdeya
- [ ] Eneyida
- [ ] KinoTron
- [ ] KinoVezha
- [ ] KlonTV
- [x] UAFlix
- [ ] UATuTFun
- [ ] UFDub
- [ ] Uakino
- [X] Unimay


## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/lampac-ukraine/lampac-ukraine.git .
   ```

2. Move the modules to the correct directory:
   - If Lampac is installed system-wide, move the modules to the `module` directory.
   - If Lampac is running in Docker, mount the volume:
     ```bash
     -v /path/to/your/cloned/repo/Uaflix:/home/module/Uaflix
     ```
